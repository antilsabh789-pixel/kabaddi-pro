// Script to set a user as admin
// Usage: npx tsx scripts/make-admin.ts <phone-number>
//
// Example: npx tsx scripts/make-admin.ts 9876543210

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const phone = process.argv[2];
  if (!phone) {
    console.log('Usage: npx tsx scripts/make-admin.ts <phone-number>');
    console.log('Example: npx tsx scripts/make-admin.ts 9876543210');
    process.exit(1);
  }

  const user = await prisma.user.findUnique({ where: { phone } });
  if (!user) {
    console.log(`No user found with phone: ${phone}`);
    process.exit(1);
  }

  const updated = await prisma.user.update({
    where: { phone },
    data: { isAdmin: true },
  });

  console.log(`✅ User "${updated.name || updated.phone}" is now an admin!`);
  console.log(`   They will see the Earnings Dashboard in their profile.`);
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
