#!/bin/bash
# Kabaddi Pro - Keep-alive server script
cd /home/z/my-project
export NODE_OPTIONS="--max-old-space-size=768"

while true; do
  echo "[$(date)] Starting Next.js server..."
  npx next start -p 3000
  EXIT_CODE=$?
  echo "[$(date)] Server exited with code $EXIT_CODE, restarting in 2s..."
  sleep 2
done
