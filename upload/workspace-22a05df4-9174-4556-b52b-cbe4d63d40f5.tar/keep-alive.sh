#!/bin/bash
# Kabaddi Pro - Auto-restart production server
# Uses 1GB memory limit for stability

PORT=3000
RESTART_COUNT=0

while true; do
  echo "[$(date)] Starting Next.js production server (attempt #$((RESTART_COUNT+1)))..."
  NODE_OPTIONS="--max-old-space-size=1024" npx next start -p $PORT -H 0.0.0.0 2>&1
  RESTART_COUNT=$((RESTART_COUNT + 1))
  echo "[$(date)] Server stopped (restart #$RESTART_COUNT). Restarting in 3 seconds..."
  sleep 3
done
