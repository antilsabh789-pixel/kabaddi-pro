#!/bin/bash
cd /home/z/my-project
NODE_OPTIONS="--max-old-space-size=1024" npx next start -p 3000 -H 0.0.0.0
