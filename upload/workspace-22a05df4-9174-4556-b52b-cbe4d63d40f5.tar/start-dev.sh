#!/bin/bash
# Keep Next.js dev server alive
while true; do
  echo "Starting Next.js dev server..."
  npx next dev -p 3000 -H 0.0.0.0 2>&1
  echo "Server stopped, restarting in 2 seconds..."
  sleep 2
done
