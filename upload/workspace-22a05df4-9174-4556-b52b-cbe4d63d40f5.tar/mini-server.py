#!/usr/bin/env python3
"""Lightweight server for Kabaddi Pro - serves Next.js static build."""
import http.server
import os
import sys

PORT = 8080
BASE_DIR = "/home/z/my-project"

class KabaddiHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)
    
    def do_GET(self):
        path = self.path.split('?')[0]  # Remove query params
        
        # Serve index.html for root
        if path == '/':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.end_headers()
            with open(os.path.join(BASE_DIR, '.next/server/app/index.html'), 'rb') as f:
                self.wfile.write(f.read())
            return
        
        # Serve static Next.js assets
        if path.startswith('/_next/static/'):
            file_path = os.path.join(BASE_DIR, path.lstrip('/'))
            if os.path.isfile(file_path):
                self.serve_file(file_path)
                return
        
        # Serve public directory files (app-icon.png, favicon.png, etc.)
        public_path = os.path.join(BASE_DIR, 'public', path.lstrip('/'))
        if os.path.isfile(public_path):
            self.serve_file(public_path)
            return
        
        # API routes - return empty JSON responses for offline mode
        if path.startswith('/api/'):
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(b'{}')
            return
        
        # SPA fallback - serve index.html for any unknown route
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.end_headers()
        with open(os.path.join(BASE_DIR, '.next/server/app/index.html'), 'rb') as f:
            self.wfile.write(f.read())
    
    def serve_file(self, file_path):
        ext = os.path.splitext(file_path)[1]
        content_types = {
            '.html': 'text/html; charset=utf-8',
            '.css': 'text/css; charset=utf-8',
            '.js': 'application/javascript; charset=utf-8',
            '.json': 'application/json',
            '.png': 'image/png',
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.svg': 'image/svg+xml',
            '.ico': 'image/x-icon',
            '.woff': 'font/woff',
            '.woff2': 'font/woff2',
            '.ttf': 'font/ttf',
        }
        content_type = content_types.get(ext, 'application/octet-stream')
        self.send_response(200)
        self.send_header('Content-Type', content_type)
        self.send_header('Cache-Control', 'public, max-age=31536000')
        self.end_headers()
        with open(file_path, 'rb') as f:
            self.wfile.write(f.read())
    
    def log_message(self, format, *args):
        pass  # Suppress logging for performance

if __name__ == '__main__':
    with http.server.HTTPServer(("0.0.0.0", PORT), KabaddiHandler) as httpd:
        print(f"✅ Kabaddi Pro server running at http://localhost:{PORT}")
        sys.stdout.flush()
        httpd.serve_forever()
