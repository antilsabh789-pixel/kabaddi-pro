# Kabaddi Pro - Work Log

---
Task ID: 1
Agent: Main Coordinator
Task: Full Kabaddi Pro app overhaul - fresh start, real DB integration, player data sync

Work Log:
- Updated Prisma schema (already had phone-based User model)
- Created API route `/api/players/quick-add` for adding players by phone+name during match setup
- Added `search` query param to `/api/players` for phone/name search
- Created API route `/api/matches/save` for saving completed matches with events + player stats
- Updated Zustand store with 6 new API-connected actions: loginWithPhone, fetchPlayerByPhone, quickAddPlayer, saveMatchResult, fetchHomeData, fetchPlayerProfile
- Added dbUserId, playerProfile, homeData state fields to store
- Updated endMatch to auto-save match results to DB
- Connected AuthScreen to real API (loginWithPhone)
- Added name input to role selection step
- Completely rewrote QuickScoreTab - removed all demo data, added player search by phone/name, quick-add player form, visual player tokens in lineup
- Rewrote HomeTab - fetches real data from /api/stats (live matches, global stats, top raiders/defenders)
- Rewrote ProfileTab - fetches real profile from /api/players/[userId], shows real stats/badges/teams
- Updated TournamentsTab - removed demo data, fetches from /api/tournaments, create tournament posts to DB

Stage Summary:
- App starts fresh with no demo/hardcoded data
- Phone-based auth creates/finds users in DB
- Quick-add player by phone+name creates user in DB if not exists
- When player later logs in with same phone, all their data (stats, teams, matches) is available
- Match results saved to DB on end (teams, events, player stats all updated)
- All 4 tabs connected to real API data
- Warm pastel theme preserved throughout
- Live scoring system (dual timer, undo, revive queue, do-or-die, super tackle) works unchanged

---
Task ID: 2
Agent: Main Coordinator
Task: Update QuickScoreTab with new color theme, gender selection step, and step restructuring

Work Log:
- Replaced all `cream-50` → `warm-50`, `cream-100` → `warm-100` throughout the file
- Replaced all `coral-500` → `brand-red`, `coral-600` → `brand-red-dark`, `coral-200` → `brand-red/20` (for subtle backgrounds), `coral-300` → `brand-red-light`
- Replaced all `warm-gray-*` → `warm-*` (e.g., warm-gray-800 → warm-800, warm-gray-500 → warm-500, warm-gray-200 → warm-200, etc.)
- Added gender selection as step 0 with "Boys Match" (♂, brand-blue #0055DA) and "Girls Match" (♀, brand-red #FF0052) cards
- Updated steps array from ['Match Type', 'Team Setup', 'Lineup', 'Start'] to ['Gender', 'Match Type', 'Team Setup', 'Lineup', 'Start']
- Adjusted all step numbers: Gender=0, Match Type=1, Team Setup=2, Lineup=3, Start=4
- Added `matchGender` state with useState<string>('boys')
- Updated startMatch call to pass matchGender as 4th parameter: `startMatch(homeTeam, awayTeam, isPractice, matchGender)`
- Added gender badge in match summary (step 4) showing "♂ Boys Match" or "♀ Girls Match" with conditional colors
- Added accentColor/accentBg/accentBgDark computed values based on matchGender
- Updated FAB button from coral-500 to brand-red
- Updated step indicator from coral-500 to brand-red
- Updated navigation button max step from 3 to 4
- Updated resetWizard to include setMatchGender('boys')
- Added matchGender to handleStartMatch dependency array
- Lint passes cleanly with no errors

Stage Summary:
- All old color references (cream, coral, warm-gray) fully replaced with new naming convention
- Gender selection is now the first step in the match setup wizard
- 5-step wizard: Gender → Match Type → Team Setup → Lineup → Start
- Gender is passed through to the store's startMatch function and displayed in match summary
- Conditional styling: Boys uses brand-blue (#0055DA), Girls uses brand-red (#FF0052)

---
Task ID: 2
Agent: Main Coordinator
Task: Color theme migration and gender feature additions to HomeTab.tsx and page.tsx

Work Log:
- Updated HomeTab.tsx with complete color theme migration:
  - `cream-50` → `warm-50`, `cream-100` → `warm-100`
  - `coral-500` → `brand-red`, `coral-600` → `brand-red-dark`, `coral-700` → `brand-red-dark`
  - `coral-200` → `brand-red-light` / `brand-red/20` for subtle backgrounds
  - `warm-gray-*` → `warm-*` (warm-gray-800→warm-800, warm-gray-500→warm-500, warm-gray-300→warm-300, warm-gray-200→warm-200)
- Added `gender?: string | null` field to LiveMatch interface
- Added gender badges to live match cards: "♂ Boys Match" (brand-blue) / "♀ Girls Match" (brand-red)
- Added gender filter toggle buttons (All / Boys / Girls) above live matches section
  - All button uses warm neutral colors
  - Boys button uses brand-blue colors
  - Girls button uses brand-red colors
- Updated greeting to show "Hello, [Name]! ♂/♀ 👋" with gender icon colored by brand-blue (male) or brand-red (female)
- Updated chart/stat colors: Total Players uses brand-red, Active Tournaments uses brand-gold, Total Teams uses brand-blue
- Updated award player colors to use brand-gold and brand-red theme
- Updated page.tsx with same color theme migration:
  - `cream-50` → `warm-50`, `cream-100` → `warm-100`
  - `coral-500` → `brand-red`, `coral-600` → `brand-red-dark`
  - `warm-gray-*` → `warm-*`
- Updated BottomNav component to use new color scheme:
  - Active tab color: `brand-red` instead of `coral-500`
  - Quick Score button: `bg-brand-red` and `shadow-brand-red/*` instead of coral variants
  - Nav indicator: `bg-brand-red` instead of `bg-coral-500`
  - Notification dot border: `border-warm-100` instead of `border-cream-100`
- Lint passed with no errors
- Dev server compiles successfully

Stage Summary:
- All color references migrated from old (cream/coral/warm-gray) to new (warm/brand-red/brand-blue/brand-gold) theme
- Gender feature fully implemented: filter toggles, match badges, greeting indicator
- Both files updated and compiling cleanly

## 2025-01-XX — AuthScreen Component Update

### Task
Update AuthScreen component with new color theme, signup fields, details stage, and gender-themed visuals.

### Changes Made

#### 1. Color Theme Update (`AuthScreen.tsx`)
- `cream-50` → `warm-50`
- `cream-100` → `warm-100`
- `coral-500` → `brand-red`
- `coral-600` → `brand-red-dark`
- `coral-700` → `brand-red-dark`
- `coral-200/20` → `brand-red/20`
- `warm-gray-800` → `warm-800`
- `warm-gray-600` → `warm-600`
- `warm-gray-500` → `warm-500`
- `warm-gray-300` → `warm-300`
- `warm-gray-200` → `warm-200`
- `warm-gray-700` → `warm-700`
- Role card gradients also updated: player → brand-red, coach → brand-green, organizer → brand-gold

#### 2. New Signup Fields (details stage)
- **Gender**: Two large buttons (Boy ♂ / Girl ♀) with brand-blue (#0055DA) for boy, brand-red (#FF0052) for girl. Selected state fills button with color + white text/icons.
- **Weight**: Number input with "kg" suffix shown as positioned overlay text
- **Practice Ground**: Text input with placeholder "Enter practice ground / academy"

#### 3. New 'details' Stage
- Stage type updated: `'auth' | 'details' | 'role'` (was `'auth' | 'role'`)
- After registration, user goes to details → role (was auth → role directly)
- Login (returning users) skips details and goes straight to onboarded
- `goBack` updated: role → details → auth

#### 4. Updated handleAuth & Login Flow
- `handleAuth` now sends `gender`, `weight`, `practiceGround` in the registration/login request body
- `login` call passes gender/weight/practiceGround from API response or local state

#### 5. Gender-themed Visual Differences
- Continue button on details stage: boy → brand-blue, girl → brand-red
- Get Started button on role stage: boy → brand-blue, girl → brand-red
- Accent bar shown on details stage with gender color (#0055DA or #FF0052)

#### 6. Progress Dots
- Updated from 2 dots (auth, role) to 3 dots (auth, details, role)
- Active dot: w-8 bg-brand-red, completed: w-4 bg-brand-red-dark, upcoming: w-4 bg-warm-300

#### 7. API Route Update (`/api/auth/route.ts`)
- Added `update-details` action to persist gender/weight/practiceGround after onboarding
- Updated action comment to document new action type

#### 8. Cleanup
- Removed unused `Lock` import from lucide-react
- Removed unused computed CSS class variables (genderAccentClass, genderBgClass, genderBgLightClass)

### Files Modified
- `src/components/kabaddi/AuthScreen.tsx`
- `src/app/api/auth/route.ts`

### Verification
- ESLint: No errors
- Dev server: Compiling successfully

---

## 2025-03-04 — TournamentsTab & ProfileTab Color Theme + Gender/Profile Updates

### Task
Update TournamentsTab.tsx and ProfileTab.tsx with new color theme, gender features, and profile field additions.

### Changes Made

#### 1. TournamentsTab.tsx — Color Theme Update
- `cream-50` → `warm-50`, `cream-100` → `warm-100`
- `coral-500` → `brand-red`, `coral-600` → `brand-red-dark`, `coral-700` → `brand-red-dark`
- `coral-200` → `brand-red-light` (e.g., `bg-brand-red-light/30 text-brand-red border-brand-red-light/50`)
- `warm-gray-*` → `warm-*` (warm-gray-800→warm-800, warm-gray-500→warm-500, warm-gray-200→warm-200, etc.)

#### 2. TournamentsTab.tsx — Gender Feature
- Added `gender?: string | null` field to `TournamentData` interface
- Added `formGender` state: `const [formGender, setFormGender] = useState('boys');`
- Added "Gender Category" Select field in Create Tournament dialog (before Venue field) with "Boys" and "Girls" options
- Passing `gender: formGender` in the POST request body when creating a tournament
- Resetting `formGender` to 'boys' on dialog close
- Added `GenderBadge` component showing "Boys" (brand-blue) or "Girls" (brand-red) on tournament cards
- Added gender filter toggle in header area: All / Boys / Girls buttons
  - All uses warm neutral colors
  - Boys uses brand-blue colors (`bg-brand-blue/20 border-brand-blue/40 text-brand-blue`)
  - Girls uses brand-red colors (`bg-brand-red/20 border-brand-red/40 text-brand-red`)
- Added `genderFilter` state and filtering logic in `filteredTournaments`

#### 3. ProfileTab.tsx — Color Theme Update
- `cream-50` → `warm-50`, `cream-100` → `warm-100`
- `coral-500` → `brand-red`, `coral-600` → `brand-red-dark`, `coral-700` → `brand-red-dark`
- `coral-200` → `brand-red-light` / `brand-red/20`
- `warm-gray-*` → `warm-*` (all instances)

#### 4. ProfileTab.tsx — Gender Display
- Added `gender`, `weight`, `practiceGround` fields to `PlayerProfileData.user` interface
- Display gender next to name: "♂ Boy" (brand-blue) or "♀ Girl" (brand-red)

#### 5. ProfileTab.tsx — Weight & Practice Ground Display
- Show weight (kg) and practice ground in the profile header area below position/weight category info
- Added `MapPin` icon import for practice ground display
- Both shown conditionally with icons in a flex-wrap row

#### 6. ProfileTab.tsx — Edit Form Updates
- Added `gender`, `weight`, `practiceGround` fields to `editForm` state
- Added Gender Select (Boys/Girls), Weight (number input), and Practice Ground (text input) to the edit dialog
- Populated from `profileData.user.gender`, `profileData.user.weight`, `profileData.user.practiceGround`
- Passing `gender`, `weight`, `practiceGround` in the PUT request body

#### 7. ProfileTab.tsx — Chart Color Updates
- Bar chart fill color: `#E36A6A` → `#FF0052` (brand-red)
- Radar chart stroke/fill: `#E36A6A` → `#FF0052` (brand-red)

### Files Modified
- `src/components/kabaddi/TournamentsTab.tsx`
- `src/components/kabaddi/ProfileTab.tsx`

### Verification
- ESLint: No errors
- Dev server: Compiling successfully

## 2026-03-05 — Stats API Gender Filter Update

### Task
Update `/src/app/api/stats/route.ts` to add gender field to live match details and gender-based filtering.

### Changes Made
1. **Added `gender` field to live match details**: The `Match` model already has a `gender` field in the Prisma schema. Since `findMany` with `include` returns all scalar fields by default, the `gender` field is now included in the live match details response automatically.

2. **Added gender-based filtering support**:
   - Changed function signature from `GET()` to `GET(request: NextRequest)` to access URL search params.
   - Parse `gender` query parameter from URL; validate it's "boys" or "girls" (otherwise ignored/no filter).
   - **Match counts**: Applied `matchWhere` filter (with `gender` condition) to all `db.match.count()` calls (total, live, completed, upcoming).
   - **Live match details**: Applied same `matchWhere` filter to the `db.match.findMany()` query for live matches.
   - **Top raiders/defenders**: Applied `playerGenderWhere` filter that filters through the `user` relation on `PlayerProfile` by `user.gender`.

### Files Modified
- `src/app/api/stats/route.ts`

### Validation
- Lint passes cleanly (`bun run lint`)
- Dev server compiles without errors

## 2026-03-05 — Color Theme & Gender Badge Update

### Files Modified
1. `/home/z/my-project/src/components/kabaddi/LiveScoringScreen.tsx`
2. `/home/z/my-project/src/components/kabaddi/SplashScreen.tsx`

### Changes — LiveScoringScreen.tsx
- **Color theme migration**: Replaced all old color tokens with new brand tokens:
  - `cream-50` → `warm-50`
  - `cream-100` → `warm-100`
  - `coral-500` → `brand-red`
  - `coral-600` → `brand-red-dark`
  - `coral-200` → `brand-red-light`
  - `warm-gray-800` → `warm-800`
  - `warm-gray-700` → `warm-700`
  - `warm-gray-600` → `warm-600`
  - `warm-gray-500` → `warm-500`
  - `warm-gray-400` → `warm-400`
  - `warm-gray-300` → `warm-300`
  - `warm-gray-200` → `warm-200`
  - `warm-gray-80` → `warm-80`
- **Gender badge**: Added a small badge in the match header top info row that displays:
  - "♂ Boys Match" with `bg-brand-blue` for boys
  - "♀ Girls Match" with `bg-brand-red` for girls
  - Conditionally rendered when `activeMatch.gender` is set

### Changes — SplashScreen.tsx
- **Color theme migration**: Same replacements as above where applicable:
  - `cream-50` → `warm-50`
  - `coral-500` → `brand-red`
  - `coral-700` → `brand-red-dark`
  - `coral-200` → `brand-red-light`
  - `warm-gray-800` → `warm-800`
  - `warm-gray-600` → `warm-600`
  - `warm-gray-500` → `warm-500`
  - `warm-gray-300` → `warm-300`
- **Gradient colors**: Updated all gradient references (`from-coral-500/5`, `bg-coral-500/10`, etc.) to use new brand colors

### Verification
- Grep confirmed zero remaining `coral-`, `cream-`, or `warm-gray-` references in both files

---
Task ID: 1-10
Agent: Main
Task: Complete color theme change (#FF0052, #FFD400, #00C68D, #0055DA), add gender/weight/practice ground to signup, implement gender separation throughout app

Work Log:
- Updated Prisma schema: added gender, weight, practiceGround to User model; added gender to Match and Tournament models
- Ran db:push to sync database schema
- Updated globals.css with new color theme: brand-red (#FF0052), brand-gold (#FFD400), brand-green (#00C68D), brand-blue (#0055DA), warm-50/100/200/300/400/500/600/700/800
- Updated store.ts: added gender, weight, practiceGround to CurrentUser interface; added gender to ActiveMatch; updated startMatch to accept gender parameter
- Updated auth API route to handle gender, weight, practiceGround in register and quick-add flows; added update-details action
- Updated matches API to accept and store gender field; added gender filtering in GET
- Updated tournaments API to accept and store gender field; added gender filtering in GET
- Updated stats API to support gender-based filtering
- Updated players API and players/[id] API to include gender/weight/practiceGround in user select and handle them in PUT
- Updated AuthScreen: added new 'details' stage between auth and role for gender/weight/practiceGround selection; gender-themed visuals (blue for boys, red for girls); 3-stage progress dots
- Updated HomeTab: added gender badges on live matches (Boys Match/Girls Match); gender filter buttons (All/Boys/Girls); gender icon in greeting; all colors updated
- Updated page.tsx: BottomNav uses new brand-red color scheme
- Updated QuickScoreTab: added Step 0 for gender selection (Boys/Girls cards); 5 steps now; gender badge in match summary; startMatch passes gender
- Updated TournamentsTab: added Gender Category in create dialog; gender badge on tournament cards; gender filter toggle
- Updated ProfileTab: shows gender icon next to name; displays weight and practice ground; edit form includes gender/weight/practiceGround
- Updated LiveScoringScreen: gender badge in header; all colors updated
- Updated SplashScreen: all colors updated to new brand theme
- Updated Leaderboard: all colors updated
- Lint passes cleanly
- Dev server runs without errors
- Registration API verified working with gender/weight/practiceGround fields

Stage Summary:
- New color theme: #FF0052 (brand-red), #FFD400 (brand-gold), #00C68D (brand-green), #0055DA (brand-blue)
- Gender separation throughout app: Boys use brand-blue (#0055DA), Girls use brand-red (#FF0052)
- Signup flow: auth → details (gender/weight/practiceGround) → role selection
- Match scoring: Step 0 asks gender before match type
- Tournaments: Gender category field in creation, gender filter
- Live matches: Clearly labeled "Boys Match" / "Girls Match"
- All API routes support gender field
- Database schema includes gender on User, Match, and Tournament

---
Task ID: 6
Agent: Tab Enhancer
Task: Enhance TournamentsTab component with team management features

Work Log:
- Completely rewrote TournamentsTab.tsx with full team management integration
- Added new type interfaces: TeamMemberUser, TeamMember, TeamDetail, PlayerSearchResult
- Extended TournamentEntry type to include optional `members` array for team detail display
- Added TEAM_COLORS constant with 16 color presets for team creation
- Added PlayerAvatar helper component for consistent player avatars throughout dialogs

### New State Variables
- `addTeamOpen` / `manageTeamsOpen` / `createTeamOpen` / `teamDetailSheetOpen` / `addPlayerOpen` — dialog open states
- `allTeams` / `teamSearch` / `teamsLoading` — for Add Team dialog (search existing teams)
- `newTeamName` / `newTeamShortName` / `newTeamColor` / `creatingTeam` — Create Team form
- `newTeamPlayerSearch` / `newTeamPlayerResults` / `newTeamSelectedPlayers` / `newTeamSearching` — player selection during team creation
- `selectedTeam` / `teamDetailLoading` — team detail view
- `playerSearch` / `playerSearchResults` / `playerSearching` — Add Player dialog search
- `quickAddName` / `quickAddPhone` / `quickAddJersey` / `quickAdding` — Quick Add Player form

### New Functions
- `fetchAllTeams()` — fetches all teams from `/api/teams` for search
- `fetchTeamDetail(teamId)` — fetches team with members from `/api/teams/{id}`
- `searchPlayers()` — reusable debounced player search hitting `/api/players?search=xxx`
- `handleAddTeamToTournament(teamId)` — PATCH `/api/tournaments/{id}` with `{ addTeamIds: [teamId] }`
- `handleRemoveTeamFromTournament(teamId)` — PATCH `/api/tournaments/{id}` with `{ removeTeamIds: [teamId] }`
- `handleCreateTeam()` — POST `/api/teams` then auto-adds to tournament via PATCH
- `handleAddPlayerToTeam(userId)` — PATCH `/api/teams/{id}` with `{ addPlayerIds: [userId] }`
- `handleRemovePlayerFromTeam(userId, name)` — PATCH `/api/teams/{id}` with `{ removePlayerIds: [userId] }`
- `handleSetCaptain(userId, name)` — PATCH `/api/teams/{id}` with `{ captainId: userId }`
- `handleQuickAddPlayer()` — POST `/api/players/quick-add` then adds to team or selection

### New Dialogs
1. **Add Team Dialog** — searches all teams, filters out teams already in tournament, click to add
2. **Manage Teams Dialog** — shows all teams in tournament with stats and remove (X) button; click team name to open detail
3. **Create Team Dialog** — full form with name, short name, color picker (16 presets), optional player search + selection, quick-add player form
4. **Team Detail Dialog** — shows team with player list (avatars, jersey #, position, phone, captain crown), Add Player button, Set Captain (crown icon), Remove Player (minus icon), Remove from Tournament button
5. **Add Player Dialog** — search existing players (debounced), quick-add new player form, auto-adds to team

### Expanded Tournament Section
When a tournament card is expanded, now shows:
- Team chips list (clickable to open team detail) with color dots and short names
- Four action buttons: Brackets, Add Team (green), Manage (blue), Create Team

### Preserved Functionality
- Status tabs (Ongoing / Upcoming / Past)
- Gender filter toggle (All / Boys / Girls)
- Tournament card display with badges
- Points table with team stats
- Bracket view dialog
- Create tournament dialog with all fields
- All framer-motion animations
- All existing API integrations

### Files Modified
- `src/components/kabaddi/TournamentsTab.tsx`

### Verification
- ESLint: No errors
- Dev server: Compiles successfully

---
Task ID: 3
Agent: Feature Developer
Task: Rewrite QuickScoreTab with Match Settings step, flexible player count, avatar upload, and ProfileTab avatar support

Work Log:

### 1. QuickScoreTab.tsx — Complete Rewrite

#### New Step: "Match Settings" (Step 2)
- Added step between "Match Type" (1) and "Team Setup" (3)
- Updated steps array: ['Gender', 'Match Type', 'Match Settings', 'Team Setup', 'Lineup', 'Start'] (6 steps)
- Added `halfDuration` state (default 20) with selector options: 5, 10, 15, 20, 25, 30 minutes
- Added `playersPerSide` state (default 7) with selector options: 1-12
- Added match preview card: "2 halves × 20 min = 40 min total" + player count info
- Used brand-gold for timer icon, brand-green for players icon
- Added `HALF_DURATION_OPTIONS` and `PLAYERS_PER_SIDE_OPTIONS` constants
- Imported `Select`, `SelectContent`, `SelectItem`, `SelectTrigger`, `SelectValue` from shadcn/ui
- Imported `Timer`, `UsersRound`, `Camera` from lucide-react

#### Updated Step Flow
- Step 0: Gender Selection (unchanged)
- Step 1: Match Type (unchanged)
- Step 2: Match Settings (NEW)
- Step 3: Team Setup (was step 2)
- Step 4: Lineup (was step 3)
- Step 5: Start (was step 4)
- Navigation max step updated from 4 to 5
- All step condition blocks updated to match new numbering

#### Flexible Player Count
- Removed hardcoded minimum 7 players requirement from `handleRemovePlayer`
- Now uses `playersPerSide` state: `if (prev.length <= playersPerSide)`
- `canRemove` prop on LineupPlayerToken uses `teamALineup.length > playersPerSide` (was hardcoded 7)
- Updated "Need at least X players" messages to use `playersPerSide` dynamically
- `ensureMinPlayers` in `handleStartMatch` fills to `playersPerSide` instead of 7
- `toPlayerInMatch` uses `index < playersPerSide` for `isOnMat` (was `index < 7`)
- Start step summary uses `playersPerSide` for starting/sub counts

#### Pass halfDuration and playersPerSide to startMatch
- Updated `startMatch` call: `startMatch(homeTeam, awayTeam, isPractice, matchGender, halfDuration, playersPerSide)`
- Added `halfDuration` and `playersPerSide` to `handleStartMatch` dependency array

#### Start Step (Step 5) Enhancements
- Added match settings badges showing half duration and players per side
- Added total match time badge
- Player list preview shows avatars when available
- Jersey number styling uses `playersPerSide` threshold for starting vs bench indicator

#### Avatar Upload in Quick-Add Form
- Added `quickAddAvatarFile` and `quickAddAvatarPreview` states
- Added `quickAddAvatarRef` for hidden file input
- Added avatar section at top of quick-add form with camera icon button
- Shows circular preview of selected image before adding
- File picker accepts JPEG, PNG, WebP, GIF (max 5MB)
- After player creation via `/api/players/quick-add`, if avatar file selected, uploads to `/api/upload/avatar`
- Avatar URL from upload response is stored in the player's `avatarUrl`
- Added remove button for selected avatar
- Reset avatar state on form close/reset

#### SearchResultItem Enhancement
- Added `avatarUrl` prop to `SearchResultItem` component
- Shows avatar image when available instead of generic User icon

#### Reset Wizard Updates
- Added `setHalfDuration(20)` and `setPlayersPerSide(7)` to resetWizard
- Added `setQuickAddAvatarFile(null)` and `setQuickAddAvatarPreview('')`

### 2. ProfileTab.tsx — Avatar Upload Support

- Added `useRef` import
- Added `Camera` icon import from lucide-react
- Added `AvatarImage` import (was only using `AvatarFallback`)
- Added `avatarUploading` state and `avatarInputRef` ref
- Added `handleAvatarUpload` function that:
  - Validates file size (max 5MB) and type (JPEG, PNG, WebP, GIF)
  - Uploads to `/api/upload/avatar` via FormData with file and userId
  - Updates `profileData` locally with new avatar URL
  - Updates `currentUser` in store via `login()` with new avatar
  - Shows success/error toast notifications
- Updated profile header Avatar component:
  - Wrapped in clickable div with `group cursor-pointer`
  - Added `AvatarImage` with `src={profileData.user.avatar}` when available
  - Added camera overlay that appears on hover (dark overlay with Camera icon)
  - Shows spinner during upload
  - Hidden file input triggered by click
  - Input resets after selection so same file can be re-selected

### Files Modified
- `src/components/kabaddi/QuickScoreTab.tsx` — Complete rewrite with all 6 features
- `src/components/kabaddi/ProfileTab.tsx` — Avatar upload support added

### Verification
- ESLint: No errors (`bun run lint` passes)
- Dev server: Compiles successfully

---
Task ID: Final
Agent: Main Coordinator
Task: Integrate all new features, verify, and finalize

Work Log:
- Updated Prisma schema: added halfDuration (Int, default 20) and playersPerSide (Int, default 7) to Match model
- Ran db:push to sync database schema
- Updated store.ts: added halfDuration and playersPerSide to ActiveMatch interface; updated startMatch to accept these params; removed hardcoded HALF_DURATION_SECONDS; nextHalf uses match's halfDuration
- Updated saveMatchResult in store to pass halfDuration and playersPerSide to matches API
- Updated matches API (POST) to accept and store halfDuration and playersPerSide with validation
- Created avatar upload API at /api/upload/avatar (POST, accepts FormData with file and userId)
- Created upload directories (public/uploads/avatars)
- Enhanced tournaments/[id] API with PATCH support for adding/removing teams (addTeamIds, removeTeamIds)
- Enhanced teams/[id] API with PATCH support for adding/removing players and setting captain
- Added DELETE support for teams/[id]
- Subagent 1 (QuickScoreTab): Added Match Settings step with half duration and players per side selectors; flexible player count; avatar upload in quick-add form; ProfileTab avatar upload
- Subagent 2 (TournamentsTab): Added team management with Add Team, Create Team, Manage Teams, Team Detail dialogs; player management with add/remove/captain features
- Added match format badge to LiveScoringScreen header (e.g., "7v7 · 20min")
- Browser verification: Auth screen, Quick Score tab with Match Settings step, Tournaments tab, Profile tab all working correctly
- Lint passes cleanly, dev server runs without errors

Stage Summary:
- **Match Time Settings**: Half duration configurable (5-30 min), not hardcoded to 20 min
- **Flexible Player Count**: Players per side configurable (1-12), not mandatory 7
- **Profile Pictures**: Avatar upload API + upload in ProfileTab and Quick-Add form
- **Easier Tournament Management**: Add/remove teams, create teams, manage players in teams
- **Team Player Management**: Add/remove players, set captain, all from tournament view
- All features verified in browser
