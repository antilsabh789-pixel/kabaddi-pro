'use client';

import { useState } from 'react';
import { useKabaddiStore } from '@/lib/store';
import { motion, AnimatePresence } from 'framer-motion';
import { Home as HomeIcon, Trophy, PlusCircle, User } from 'lucide-react';
import SplashScreen from '@/components/kabaddi/SplashScreen';
import AuthScreen from '@/components/kabaddi/AuthScreen';
import HomeTab from '@/components/kabaddi/HomeTab';
import TournamentsTab from '@/components/kabaddi/TournamentsTab';
import QuickScoreTab from '@/components/kabaddi/QuickScoreTab';
import ProfileTab from '@/components/kabaddi/ProfileTab';
import LiveScoringScreen from '@/components/kabaddi/LiveScoringScreen';

const tabs = [
  { id: 'home' as const, label: 'Home', icon: HomeIcon },
  { id: 'tournaments' as const, label: 'Tournaments', icon: Trophy },
  { id: 'quick-score' as const, label: 'Quick Score', icon: PlusCircle },
  { id: 'profile' as const, label: 'Profile', icon: User },
];

export default function Home() {
  const [showSplash, setShowSplash] = useState(true);
  const { isAuthenticated, isOnboarded, activeTab, setActiveTab, activeMatch } =
    useKabaddiStore();

  // Show splash screen on first load
  if (showSplash) {
    return <SplashScreen onComplete={() => setShowSplash(false)} />;
  }

  // Show auth/onboarding if not authenticated
  if (!isAuthenticated || !isOnboarded) {
    return <AuthScreen />;
  }

  // If there's an active live match, show the scoring screen
  if (activeMatch?.isLive && activeTab === 'quick-score') {
    return (
      <div className="min-h-screen bg-warm-50 flex flex-col">
        <LiveScoringScreen />
        <BottomNav
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          hasLiveMatch={!!activeMatch?.isLive}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-warm-50 flex flex-col">
      {/* Main Content */}
      <main className="flex-1 overflow-y-auto pb-20">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
          >
            {activeTab === 'home' && <HomeTab />}
            {activeTab === 'tournaments' && <TournamentsTab />}
            {activeTab === 'quick-score' && <QuickScoreTab />}
            {activeTab === 'profile' && <ProfileTab />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        hasLiveMatch={!!activeMatch?.isLive}
      />
    </div>
  );
}

function BottomNav({
  activeTab,
  setActiveTab,
  hasLiveMatch,
}: {
  activeTab: string;
  setActiveTab: (tab: 'home' | 'tournaments' | 'quick-score' | 'profile') => void;
  hasLiveMatch: boolean;
}) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-warm-100/95 backdrop-blur-lg border-t border-warm-300 z-50 safe-bottom">
      <div className="max-w-lg mx-auto flex items-center justify-around px-2 pt-2 pb-3">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          const isQuickScore = tab.id === 'quick-score';
          const Icon = tab.icon;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`relative flex flex-col items-center justify-center gap-0.5 min-w-[64px] py-1 transition-colors duration-200 ${
                isQuickScore ? '-mt-5' : ''
              } ${isActive ? 'text-brand-red' : 'text-warm-500'}`}
            >
              {isQuickScore ? (
                <div
                  className={`flex items-center justify-center w-14 h-14 rounded-full shadow-lg transition-all duration-200 ${
                    isActive
                      ? 'bg-brand-red shadow-brand-red/30'
                      : hasLiveMatch
                        ? 'bg-brand-red shadow-brand-red/20 animate-pulse'
                        : 'bg-brand-red shadow-brand-red/20'
                  }`}
                >
                  <Icon className="w-6 h-6 text-white" />
                  {hasLiveMatch && !isActive && (
                    <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-warm-100 animate-pulse" />
                  )}
                </div>
              ) : (
                <Icon className="w-5 h-5" />
              )}
              <span
                className={`text-[10px] font-medium ${isQuickScore ? 'mt-1' : ''}`}
              >
                {tab.label}
              </span>
              {isActive && !isQuickScore && (
                <motion.div
                  layoutId="nav-indicator"
                  className="absolute -top-2 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-brand-red rounded-full"
                  transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
