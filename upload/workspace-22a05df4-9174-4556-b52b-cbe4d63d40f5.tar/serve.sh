#!/bin/bash
cd /home/z/my-project
while true; do
  node node_modules/.bin/next start -p 3000 -H 0.0.0.0
  EXIT_CODE=$?
  echo "Server exited with code $EXIT_CODE, restarting in 3s..." >> /tmp/serve-restart.log
  sleep 3
done
