# Task 7: SocialFeedScreen Component

## Summary
Created `/home/z/my-project/src/components/kabaddi/SocialFeedScreen.tsx` — a full-screen social activity feed component for the Kabaddi Pro app.

## What was built
- **SocialFeedScreen** component with `onClose` prop
- Fetches activities from `GET /api/activities?userId=xxx&limit=20&offset=0`
- Supports 4 activity types with distinct visual treatment:
  - `match_completed` — brand-red, Trophy icon, score card with team names/scores
  - `achievement_unlocked` — brand-gold, Award icon, achievement name + icon
  - `tournament_joined` — brand-teal, Flag icon, tournament name + team count
  - `player_milestone` — brand-navy, Milestone icon, milestone type + value
- Activity cards with: user avatar (with gender icon), name, description, relative timestamp, activity type icon, and type-specific rich content
- Pull-to-refresh via header RefreshCw button with spinning animation
- Empty state: "No activity yet. Follow players to see their updates!"
- **Suggested Players** section (shown in empty state AND at bottom of feed):
  - Fetches from `/api/follow?userId=xxx&type=search`
  - Shows top 5 (empty state) or top 3 (feed bottom) unfollowed players
  - Follow/Unfollow buttons with optimistic UI updates
  - Following a suggested player refreshes the feed
- Loading skeleton states for both activities and suggested players
- Framer-motion staggered mount animations on cards
- "You" badge on own activities
- Load More pagination support
- Full-screen overlay design: `fixed inset-0 z-50 bg-warm-50`

## Design Patterns
- Follows existing project conventions (same as LeaderboardScreen, FollowScreen, MatchAwardsScreen)
- Uses shadcn/ui Card, Badge, Button components
- Uses brand color tokens (brand-red, brand-gold, brand-teal, brand-navy, warm-*)
- Uses useKabaddiStore for currentUser access
- Uses useToast for follow/unfollow feedback
- `'use client'` directive included
- ESLint passes with 0 errors, 0 warnings

## API Dependencies
- `GET /api/activities` — already exists
- `GET /api/follow?type=search` — already exists
- `POST /api/follow` — already exists for follow/unfollow actions
