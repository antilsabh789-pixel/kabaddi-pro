# Task 2 — FollowScreen Component

## Summary
Created `/home/z/my-project/src/components/kabaddi/FollowScreen.tsx` — a polished full-screen overlay for following/unfollowing players.

## Features Implemented
1. **Full-screen overlay** with `fixed inset-0 z-50 bg-warm-50`, slide-up from bottom via Framer Motion spring animation
2. **Header** with back button (ArrowLeft), "FOLLOW & CONNECT" title with brand-red gradient icon, follower/following counts displayed
3. **3 pill-style tabs**: Search | Followers | Following — active tab uses brand-red gradient, inactive uses warm-100
4. **Search tab**:
   - Search input with icon, debounced (300ms) API calls
   - Player results list with avatar circle + first-letter fallback, name, gender icon, phone, follow/unfollow button
   - Empty states for no-query and no-results
5. **Followers tab**:
   - List of followers with avatar, name, gender icon, "Followed you X ago" timestamp, follow-back button
   - Checks which followers the current user follows back
6. **Following tab**:
   - List of followed users with avatar, name, gender icon, "Following since X ago", unfollow button
   - Unfollowing removes from list instantly
7. **Follow button**: rounded-full, brand-teal "Follow" / warm-200 "Following" with hover-to-unfollow (red tint)
8. **Gender icons**: ♂ in brand-blue for male, ♀ in brand-red for female
9. **Loading skeletons** while fetching data
10. **Empty states** with relevant icons and messages
11. **Optimistic UI updates** on follow/unfollow with count refresh
12. **Toast notifications** on follow/unfollow actions

## API Integration
- `GET /api/follow?userId=xxx&type=counts` — follower/following counts
- `GET /api/follow?userId=xxx&type=search&search=query` — search players with isFollowing status
- `GET /api/follow?userId=xxx&type=followers` — follower list with followedAt
- `GET /api/follow?userId=xxx&type=following` — following list with followedAt
- `POST /api/follow` — { followerId, followingId, action: 'follow'|'unfollow' }

## Design System
- Uses warm-50/100/200/400/500/600/800 palette, brand-red gradient, brand-teal, brand-navy
- Card-based lists with divide-y separators
- Custom scrollbar, backdrop blur header
- Consistent with LeaderboardScreen, TeamManagementScreen patterns

## Lint & Build
- ESLint passes clean
- Dev server running successfully
