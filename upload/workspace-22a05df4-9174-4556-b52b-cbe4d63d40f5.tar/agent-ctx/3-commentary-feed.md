# Task 3: CommentaryFeed Component

## Summary
Created `/home/z/my-project/src/components/kabaddi/CommentaryFeed.tsx` - a live commentary feed component for real-time match commentary display.

## What was built
- Full `CommentaryFeed` component accepting `CommentaryFeedProps` interface
- Scrollable feed with newest entries at top
- Each entry includes:
  - Color dot (from `getCommentaryDotColor`)
  - Auto-generated commentary text (from `generateCommentary`)
  - Timestamp (minutes:seconds into the half)
  - Team indicator badge (H/A with team color)
  - Point value badge (+N) when value > 0
  - Event icon emoji
- "MATCH STARTED" header with pulsing dots
- Half separator badges ("1st Half" / "2nd Half")
- Key moment highlights for Super Raid, Super Tackle, All Out, Do-or-Die:
  - Distinct accent backgrounds per type (orange, purple, red, amber)
  - Ring glow overlay with blur effect
  - Pulse animation for super raid and all out
  - Bold label text (⚡ SUPER RAID, 💪 SUPER TACKLE, etc.)
- Empty state: "Waiting for action..." with animated dots
- Auto-scrolls to top when new events arrive
- Framer Motion entrance animations (spring-based slide-in from left)
- Compact design suitable for side panel or bottom sheet
- Live footer with half indicator and event count
- Dark mode support throughout

## Design choices
- bg-warm-50 background matching project theme
- brand-red for raid events, brand-blue/navy for defense, brand-gold for special moments
- Key moments get distinct colored backgrounds + glow overlays + pulse animations
- Team badges use actual team colors from props
- Custom scrollbar styling from project globals
- AnimatePresence with popLayout mode for smooth entry/exit transitions

## Dependencies
- `@/lib/store` for `MatchEvent` type
- `@/lib/commentary` for `generateCommentary`, `getCommentaryDotColor`, `getCommentaryType`, `CommentaryExtras`
- `framer-motion` for animations
- `lucide-react` for Volume2 and Zap icons
