# Task 1: Create TeamManagementScreen Component

## Summary
Created `/home/z/my-project/src/components/kabaddi/TeamManagementScreen.tsx` — a full-screen overlay component for managing Kabaddi teams.

## Features Implemented

### 1. Team List View
- Fetches all teams the current user is part of via `GET /api/teams`
- Each team card displays: team name, short name badge, color badge (team initials on colored background), member count with icon, captain name with crown icon
- Tap a team card to navigate to the detail view
- Animated list with staggered entry animations
- Empty state with "No Teams Yet" message and Create Team CTA

### 2. Team Detail View
- Team header with color badge, name, short name, color dot, and member count badge
- Stats grid (4 columns): Matches, Wins, Losses, Points — with color-coded values
- Member list with avatars (initials on team color background or image), name, phone, position, captain badge (gold Crown), "YOU" badge for current user
- "Add Player" button opens Search Players Dialog
- Captain management: Crown button next to each non-captain member (only visible if current user is captain or admin)
- Remove player: Trash button next to each member, with inline delete confirmation (animated expand)
- Delete team button in header

### 3. Create Team Dialog
- Team name input (required, max 50 chars)
- Short name input (3 chars max, auto-uppercased)
- Color picker with 10 colors (same as QuickScoreTab)
- Live preview showing how the team badge will look
- Auto-adds current user as captain
- Loading state with spinner during creation
- Calls `POST /api/teams`

### 4. Search Players Dialog
- Search input with debounce (300ms)
- Calls `GET /api/players?search=xxx`
- Shows matching players with avatar, name, phone, position
- "IN TEAM" badge for players already on the team
- Tap to add (calls `PATCH /api/teams/[id]` with `addMemberId`)
- Loading skeleton during search
- Empty state for no results

## Technical Details
- Uses `'use client'` directive
- framer-motion for all animations (AnimatePresence, motion.div for list items, view transitions)
- lucide-react icons: Users, Plus, X, Search, Crown, Shield, ChevronLeft, Edit3, Trash2
- shadcn/ui components: Card, CardContent, Button, Input, Badge, Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter
- useKabaddiStore for currentUser
- useToast for success/error notifications
- fetch() for all API calls
- Brand color theme: brand-red (#DC2626), brand-navy (#1E293B), brand-teal (#14B8A6), brand-gold (#F59E0B), warm-* neutrals
- Mobile-first responsive design
- Smooth animations throughout
- Lint: passes clean
