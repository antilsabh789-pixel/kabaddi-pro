# Task 5 — AdvancedStatsScreen Component

## Task
Create `/home/z/my-project/src/components/kabaddi/AdvancedStatsScreen.tsx` — an advanced stats dashboard showing detailed player performance analytics.

## Work Completed

### Component Structure
- **Full-screen overlay** (`fixed inset-0 z-50`) with header ("ADVANCED STATS" title + close button)
- **Player Info Bar** — gradient navy card with avatar, name, jersey number, and position badge
- **6 major sections** implemented with proper Premium gating

### Sections Implemented

1. **Performance Overview**
   - SVG circular progress indicator for overall rating (brand-teal)
   - Total points, matches played, average points per match
   - Animated circular gauge with strokeDashoffset transition

2. **Raid Analysis** (Premium — wrapped in PremiumLock)
   - Raid success rate as circular gauge (brand-red)
   - Raid points per match trend — 5-bar mini chart simulated from total stats
   - Successful vs Failed raids visual bar with animated width transitions
   - Color legend below bar

3. **Defense Analysis** (Premium — wrapped in PremiumLock)
   - Tackle success rate circular gauge (brand-navy)
   - Super tackles count displayed in a highlighted card (brand-gold accent)
   - Successful vs Failed tackles visual bar with animated transitions

4. **Skill Radar** (Premium — wrapped in PremiumLock)
   - Pentagon/radar chart drawn with SVG showing 5 dimensions:
     - Raiding (based on successful raids %)
     - Defense (based on successful tackles %)
     - Bonus (based on bonus points)
     - Super Plays (based on super tackles)
     - Consistency (based on overall rating)
   - Each axis 0-100, filled with brand-teal color + animated scale-in
   - Grid levels, axis lines, data points with spring animations
   - Dimension value summary below chart

5. **Position Heatmap** (Premium — wrapped in PremiumLock)
   - Kabaddi court diagram drawn with SVG (center line, baulk lines, bonus lines, center circle)
   - Raider: highlights opponent half (right side) with red hot zones
   - Defender: highlights own half corners (left side) with navy hot zones
   - All-rounder: highlights both zones
   - Animated hot spots with spring transitions
   - Color legend and contextual description

6. **Match History**
   - Recent match performances listed (simulated from total stats)
   - Each match shows: result badge (W/L/D with color), opponent name, score, player's points
   - Staggered entry animations
   - Max height with scroll overflow

### Technical Details
- **API fetching**: Fetches from `/api/players/{userId}`, handles `{ player, profile }` response format
- **State management**: Uses `useKabaddiStore` for `currentUser` (premium check)
- **PremiumLock**: Wraps Raid Analysis, Defense Analysis, Skill Radar, and Position Heatmap
- **Framer Motion**: Staggered container/item variants, animated gauges, spring transitions
- **Brand colors**: brand-teal for overall, brand-red for raid stats, brand-navy for defense, brand-gold for super tackles
- **Responsive design**: Works on mobile-first layouts
- **Loading state**: Skeleton pulse animation while fetching
- **Error state**: Graceful fallback when no data available

### Lint & Build
- ESLint passes cleanly with no errors
- Dev server compiles successfully
